#ifndef _ASM_MIPS_KVM_PARA_H
#define _ASM_MIPS_KVM_PARA_H


#endif /* _ASM_MIPS_KVM_PARA_H */
