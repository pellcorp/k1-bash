#ifndef __ASM_MIPS_BITSPERLONG_H
#define __ASM_MIPS_BITSPERLONG_H

#define __BITS_PER_LONG _MIPS_SZLONG

#include <asm-generic/bitsperlong.h>

#endif /* __ASM_MIPS_BITSPERLONG_H */
